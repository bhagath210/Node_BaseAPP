function addChit(){
    window.location.href='/adminchits/addchits';
}